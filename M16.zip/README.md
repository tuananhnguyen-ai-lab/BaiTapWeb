# M16 – Đào tạo năng lực số

Module mẫu gồm Frontend Next.js, Backend Express và PostgreSQL.

## 1. Yêu cầu
- Node.js 18+
- PostgreSQL 14+
- Hai terminal: backend và frontend

## 2. Tạo database
Tạo database tên `learning_web`, sau đó chạy schema và seed:

```bash
createdb learning_web
cd backend
cp .env.example .env
# Sửa DATABASE_URL và JWT_SECRET trong .env
psql "$DATABASE_URL" -f db/schema.sql
npm install
npm run seed
npm run dev
```

Backend chạy tại `http://localhost:4000`.

## 3. Chạy Frontend
Mở terminal khác:

```bash
cd frontend
cp .env.local.example .env.local
npm install
npm run dev
```

Mở `http://localhost:3000/m16`.

## 4. Demo local không cần M20
Trong trình duyệt mở DevTools > Console, chạy:

```js
localStorage.setItem("demoUserId", "1");
localStorage.setItem("demoRole", "learner");
```

Để mở trang Admin:
```js
localStorage.setItem("demoRole", "admin");
location.reload();
```

Để xem trang Mentor, đặt `demoRole` thành `mentor`.

Chế độ `x-user-id` chỉ được backend chấp nhận khi `NODE_ENV=development`. Không dùng cách này khi triển khai thật.

## 5. Tích hợp M20
- M20 đăng nhập và cấp JWT.
- Frontend lưu JWT theo cơ chế chung của nhóm (ví dụ `localStorage.setItem("token", accessToken)`).
- Backend M16 xác minh JWT bằng cùng `JWT_SECRET`.
- Payload token cần có `id` (hoặc `userId`/`sub`) và `role` (`learner`, `mentor`, `admin`).
- Bỏ cơ chế demo header trong production.

Nếu M20 dùng secret bất đối xứng hoặc cấu trúc token khác, thay middleware `src/middleware/auth.js` theo chuẩn M20.

## 6. Kết nối M10
Khi người học hoàn thành node, M10 gọi:
`POST /api/m16/progress/complete`

Header: `Authorization: Bearer <token M20>`

Body:
```json
{
  "nodeId": 101,
  "nodeTitle": "HTML cơ bản",
  "eventKey": "node:101:completed"
}
```
`eventKey` phải ổn định cho mỗi lần ghi nhận hoàn thành để tránh cộng XP trùng.

## 7. Chức năng đã có
- Test đầu vào, chấm điểm ở backend và xếp trình độ.
- Lưu kết quả kiểm tra và cộng 20 XP.
- Tiến độ node; endpoint nhận sự kiện hoàn thành từ M10, cộng 30 XP.
- XP ledger chống cộng điểm trùng.
- Streak theo ngày và huy hiệu.
- Bảng xếp hạng XP.
- Quản lý câu hỏi cho Admin.
- Thống kê tiến độ cơ bản cho Mentor.
- Gợi ý bài học dạng rule-based để có thể demo khi chưa cấu hình AI.

## 8. Lưu ý phạm vi
Đây là MVP module M16 độc lập để nhóm tích hợp. Bảng `user_id` tham chiếu logic tới M20; `node_id` tham chiếu logic tới M10. Khi ghép hệ thống, thống nhất kiểu ID, schema người dùng, token và cách M10 gửi sự kiện. Bảng xếp hạng hiện hiển thị mã người dùng vì M16 không sở hữu bảng hồ sơ M20.
