import express from "express";
import cors from "cors";
import helmet from "helmet";
import dotenv from "dotenv";
import m16Routes from "./src/m16.routes.js";
import { pool } from "./src/db.js";

dotenv.config();
const app = express();
app.use(helmet());
app.use(cors({ origin: process.env.CLIENT_URL || "http://localhost:3000" }));
app.use(express.json({ limit: "1mb" }));
app.get("/api/health", async (_req, res) => {
  try { await pool.query("SELECT 1"); res.json({ status: "ok", module: "M16" }); }
  catch { res.status(503).json({ status: "database unavailable" }); }
});
app.use("/api/m16", m16Routes);
app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ message: "Lỗi máy chủ. Vui lòng thử lại." });
});
const port = process.env.PORT || 4000;
app.listen(port, () => console.log(`M16 API running at http://localhost:${port}`));
