CREATE TABLE IF NOT EXISTS m16_questions (
  id BIGSERIAL PRIMARY KEY,
  content TEXT NOT NULL,
  options JSONB NOT NULL,
  correct_answer VARCHAR(1) NOT NULL CHECK (correct_answer IN ('A','B','C','D')),
  topic VARCHAR(40) NOT NULL,
  difficulty VARCHAR(20) NOT NULL DEFAULT 'basic',
  explanation TEXT,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS m16_tests (
  id BIGSERIAL PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  description TEXT,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS m16_test_questions (
  test_id BIGINT REFERENCES m16_tests(id) ON DELETE CASCADE,
  question_id BIGINT REFERENCES m16_questions(id) ON DELETE CASCADE,
  PRIMARY KEY (test_id, question_id)
);

CREATE TABLE IF NOT EXISTS m16_test_results (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL,
  test_id BIGINT REFERENCES m16_tests(id),
  score NUMERIC(5,2) NOT NULL,
  correct_count INT NOT NULL,
  total_questions INT NOT NULL,
  level VARCHAR(30) NOT NULL,
  recommended_path VARCHAR(50) NOT NULL,
  answers JSONB NOT NULL DEFAULT '{}',
  completed_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS m16_progress (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL,
  node_id BIGINT NOT NULL,
  node_title VARCHAR(200),
  is_completed BOOLEAN NOT NULL DEFAULT FALSE,
  completed_at TIMESTAMPTZ,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(user_id, node_id)
);

CREATE TABLE IF NOT EXISTS m16_xp_events (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL,
  event_key VARCHAR(120) NOT NULL,
  reason VARCHAR(100) NOT NULL,
  xp INT NOT NULL CHECK (xp > 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(user_id, event_key)
);

CREATE TABLE IF NOT EXISTS m16_badges (
  id BIGSERIAL PRIMARY KEY,
  code VARCHAR(50) UNIQUE NOT NULL,
  name VARCHAR(100) NOT NULL,
  description TEXT NOT NULL,
  icon VARCHAR(20) NOT NULL DEFAULT '🏅',
  required_xp INT NOT NULL DEFAULT 0,
  required_streak INT NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS m16_user_badges (
  user_id BIGINT NOT NULL,
  badge_id BIGINT REFERENCES m16_badges(id) ON DELETE CASCADE,
  earned_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY(user_id, badge_id)
);

CREATE TABLE IF NOT EXISTS m16_streaks (
  user_id BIGINT PRIMARY KEY,
  current_streak INT NOT NULL DEFAULT 0,
  longest_streak INT NOT NULL DEFAULT 0,
  last_study_date DATE
);

CREATE INDEX IF NOT EXISTS idx_m16_results_user ON m16_test_results(user_id, completed_at DESC);
CREATE INDEX IF NOT EXISTS idx_m16_progress_user ON m16_progress(user_id);
CREATE INDEX IF NOT EXISTS idx_m16_xp_user ON m16_xp_events(user_id);
