import { pool } from "./db.js";

const questions = [
  ["HTML dùng thẻ nào để tạo liên kết?", {A:"<a>",B:"<p>",C:"<img>",D:"<div>"}, "A", "HTML", "basic", "Thẻ a dùng để tạo hyperlink."],
  ["Thuộc tính nào chỉ định đường dẫn ảnh?", {A:"href",B:"src",C:"alt",D:"class"}, "B", "HTML", "basic", "src chứa đường dẫn tài nguyên ảnh."],
  ["CSS dùng thuộc tính nào để đổi màu chữ?", {A:"font-style",B:"background",C:"color",D:"text-size"}, "C", "CSS", "basic", "color thiết lập màu văn bản."],
  ["Bộ chọn .card trong CSS chọn phần tử nào?", {A:"id card",B:"class card",C:"thẻ card",D:"mọi phần tử"}, "B", "CSS", "basic", "Dấu chấm chọn class."],
  ["Từ khóa khai báo biến có thể gán lại trong JavaScript là?", {A:"const",B:"let",C:"static",D:"define"}, "B", "JavaScript", "basic", "let cho phép gán lại giá trị."],
  ["Phương thức nào chọn phần tử theo CSS selector đầu tiên?", {A:"getAll()",B:"querySelector()",C:"selectOne()",D:"findClass()"}, "B", "DOM", "intermediate", "querySelector trả về phần tử đầu tiên khớp selector."]
];

async function seed() {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const test = await client.query(
      "INSERT INTO m16_tests(title,description) VALUES($1,$2) RETURNING id",
      ["Kiểm tra trình độ lập trình Web", "Bài kiểm tra mẫu gồm kiến thức HTML, CSS, JavaScript."]
    );
    for (const q of questions) {
      const inserted = await client.query(
        `INSERT INTO m16_questions(content,options,correct_answer,topic,difficulty,explanation)
         VALUES($1,$2,$3,$4,$5,$6) RETURNING id`,
        [q[0], JSON.stringify(q[1]), q[2], q[3], q[4], q[5]]
      );
      await client.query("INSERT INTO m16_test_questions(test_id,question_id) VALUES($1,$2)", [test.rows[0].id, inserted.rows[0].id]);
    }
    const badges = [
      ["first_xp","Khởi đầu","Nhận XP lần đầu","🌱",1,0],
      ["xp_100","Chăm chỉ","Đạt 100 XP","⭐",100,0],
      ["streak_3","Kiên trì","Học 3 ngày liên tiếp","🔥",0,3],
      ["streak_7","Bền bỉ","Học 7 ngày liên tiếp","🏆",0,7]
    ];
    for (const b of badges) {
      await client.query(
        `INSERT INTO m16_badges(code,name,description,icon,required_xp,required_streak)
         VALUES($1,$2,$3,$4,$5,$6) ON CONFLICT(code) DO NOTHING`, b
      );
    }
    await client.query("COMMIT");
    console.log("Seed M16 hoàn tất.");
  } catch (e) { await client.query("ROLLBACK"); throw e; }
  finally { client.release(); await pool.end(); }
}
seed().catch(e => { console.error(e); process.exit(1); });
