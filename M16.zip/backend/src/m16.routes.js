import { Router } from "express";
import { pool } from "./db.js";
import { requireAuth, requireRole } from "./middleware/auth.js";
import { classifyScore, awardXp, updateStreak, checkBadges, getDashboard } from "./m16.service.js";

const router = Router();
router.use(requireAuth);

router.get("/test", async (req, res, next) => {
  try {
    const test = await pool.query("SELECT id,title,description FROM m16_tests WHERE is_active=TRUE ORDER BY id LIMIT 1");
    if (!test.rowCount) return res.status(404).json({ message: "Chưa có bài kiểm tra." });
    const questions = await pool.query(
      `SELECT q.id,q.content,q.options,q.topic,q.difficulty
       FROM m16_test_questions tq JOIN m16_questions q ON q.id=tq.question_id
       WHERE tq.test_id=$1 AND q.is_active=TRUE ORDER BY q.id`,
      [test.rows[0].id]
    );
    res.json({ test: test.rows[0], questions: questions.rows });
  } catch (e) { next(e); }
});

router.post("/test/submit", async (req, res, next) => {
  const client = await pool.connect();
  try {
    const { testId, answers } = req.body;
    if (!testId || !answers || typeof answers !== "object" || Array.isArray(answers)) {
      return res.status(400).json({ message: "Dữ liệu nộp bài không hợp lệ." });
    }
    await client.query("BEGIN");
    const q = await client.query(
      `SELECT q.id,q.correct_answer FROM m16_test_questions tq
       JOIN m16_questions q ON q.id=tq.question_id
       WHERE tq.test_id=$1 AND q.is_active=TRUE`,
      [testId]
    );
    if (!q.rowCount) {
      await client.query("ROLLBACK");
      return res.status(404).json({ message: "Bài kiểm tra không có câu hỏi." });
    }
    let correct = 0;
    const normalized = {};
    for (const item of q.rows) {
      const answer = String(answers[item.id] || "").toUpperCase();
      normalized[item.id] = answer;
      if (answer === item.correct_answer) correct++;
    }
    const score = Math.round((correct / q.rowCount) * 100);
    const placement = classifyScore(score);
    const saved = await client.query(
      `INSERT INTO m16_test_results(user_id,test_id,score,correct_count,total_questions,level,recommended_path,answers)
       VALUES($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id,score,correct_count,total_questions,level,recommended_path,completed_at`,
      [req.user.id, testId, score, correct, q.rowCount, placement.level, placement.path, JSON.stringify(normalized)]
    );
    const gained = await awardXp(client, req.user.id, `test:${saved.rows[0].id}`, "Hoàn thành test đầu vào", 20);
    await updateStreak(client, req.user.id);
    await checkBadges(client, req.user.id);
    await client.query("COMMIT");
    res.json({ result: saved.rows[0], gainedXp: gained });
  } catch (e) {
    await client.query("ROLLBACK");
    next(e);
  } finally { client.release(); }
});

router.get("/level", async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT score,level,recommended_path,completed_at FROM m16_test_results
       WHERE user_id=$1 ORDER BY completed_at DESC LIMIT 1`, [req.user.id]
    );
    res.json({ placement: result.rows[0] || null });
  } catch (e) { next(e); }
});

router.get("/dashboard", async (req, res, next) => {
  try { res.json(await getDashboard(req.user.id)); } catch (e) { next(e); }
});

router.get("/progress", async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT node_id,node_title,is_completed,completed_at,updated_at
       FROM m16_progress WHERE user_id=$1 ORDER BY updated_at DESC`, [req.user.id]
    );
    const completed = result.rows.filter(x => x.is_completed).length;
    res.json({ items: result.rows, completed, total: result.rowCount,
      percent: result.rowCount ? Math.round(completed / result.rowCount * 100) : 0 });
  } catch (e) { next(e); }
});

// M10 gọi endpoint này khi người học hoàn thành node. eventKey giúp chống cộng XP trùng.
router.post("/progress/complete", async (req, res, next) => {
  const client = await pool.connect();
  try {
    const { nodeId, nodeTitle, eventKey } = req.body;
    if (!nodeId || !eventKey) return res.status(400).json({ message: "Thiếu nodeId hoặc eventKey." });
    await client.query("BEGIN");
    await client.query(
      `INSERT INTO m16_progress(user_id,node_id,node_title,is_completed,completed_at,updated_at)
       VALUES($1,$2,$3,TRUE,NOW(),NOW())
       ON CONFLICT(user_id,node_id) DO UPDATE SET node_title=EXCLUDED.node_title,
       is_completed=TRUE,completed_at=COALESCE(m16_progress.completed_at,NOW()),updated_at=NOW()`,
      [req.user.id, nodeId, nodeTitle || null]
    );
    const gained = await awardXp(client, req.user.id, eventKey, "Hoàn thành node học tập", 30);
    await updateStreak(client, req.user.id);
    await checkBadges(client, req.user.id);
    await client.query("COMMIT");
    res.json({ message: "Đã cập nhật tiến độ.", gainedXp: gained });
  } catch (e) {
    await client.query("ROLLBACK"); next(e);
  } finally { client.release(); }
});

router.get("/xp", async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT COALESCE(SUM(xp),0)::int AS total_xp,
       COALESCE(json_agg(json_build_object('reason',reason,'xp',xp,'createdAt',created_at)
       ORDER BY created_at DESC) FILTER (WHERE id IS NOT NULL),'[]') AS history
       FROM m16_xp_events WHERE user_id=$1`, [req.user.id]
    );
    res.json(result.rows[0]);
  } catch (e) { next(e); }
});

router.get("/badges", async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT b.id,b.code,b.name,b.description,b.icon,b.required_xp,b.required_streak,
       (ub.user_id IS NOT NULL) AS earned,ub.earned_at
       FROM m16_badges b LEFT JOIN m16_user_badges ub
       ON ub.badge_id=b.id AND ub.user_id=$1 ORDER BY b.id`, [req.user.id]
    );
    res.json({ badges: result.rows });
  } catch (e) { next(e); }
});

router.get("/streak", async (req, res, next) => {
  try {
    const result = await pool.query(
      "SELECT current_streak,longest_streak,last_study_date FROM m16_streaks WHERE user_id=$1",
      [req.user.id]
    );
    res.json(result.rows[0] || { current_streak: 0, longest_streak: 0, last_study_date: null });
  } catch (e) { next(e); }
});

router.get("/leaderboard", async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT user_id, SUM(xp)::int AS total_xp
       FROM m16_xp_events GROUP BY user_id
       ORDER BY total_xp DESC LIMIT 20`
    );
    res.json({ leaderboard: result.rows.map((row, i) => ({ rank: i + 1, ...row })) });
  } catch (e) { next(e); }
});

router.get("/recommendations", async (req, res, next) => {
  try {
    const latest = await pool.query(
      `SELECT level,recommended_path,score FROM m16_test_results
       WHERE user_id=$1 ORDER BY completed_at DESC LIMIT 1`, [req.user.id]
    );
    const progress = await pool.query(
      "SELECT node_title FROM m16_progress WHERE user_id=$1 AND is_completed=TRUE", [req.user.id]
    );
    const placement = latest.rows[0];
    let recommendations;
    if (!placement) {
      recommendations = [{ title: "Làm bài kiểm tra đầu vào", reason: "Cần xác định trình độ trước khi chọn lộ trình." }];
    } else {
      recommendations = [
        { title: placement.recommended_path, reason: `Kết quả kiểm tra gần nhất: ${placement.score}/100 (${placement.level}).` },
        { title: "Ôn tập chủ đề còn yếu", reason: "Luyện lại các kiến thức nền tảng trước khi học nội dung nâng cao." }
      ];
      if (progress.rows.length) recommendations.push({ title: "Tiếp tục node tiếp theo trong cây kỹ năng", reason: "Bạn đã hoàn thành một số nội dung trong lộ trình." });
    }
    res.json({ recommendations, generatedBy: "M16 rule-based baseline; có thể thay bằng OpenAI/Gemini sau." });
  } catch (e) { next(e); }
});

// Admin: quản lý ngân hàng câu hỏi
router.get("/admin/questions", requireRole("admin"), async (req, res, next) => {
  try {
    const result = await pool.query(
      "SELECT id,content,options,topic,difficulty,explanation,is_active,created_at FROM m16_questions ORDER BY id DESC"
    );
    res.json({ questions: result.rows });
  } catch (e) { next(e); }
});

router.post("/admin/questions", requireRole("admin"), async (req, res, next) => {
  try {
    const { content, options, correctAnswer, topic, difficulty = "basic", explanation = "" } = req.body;
    if (!content || !options || !["A","B","C","D"].includes(correctAnswer) ||
        !["A","B","C","D"].every(k => typeof options[k] === "string" && options[k].trim())) {
      return res.status(400).json({ message: "Câu hỏi cần nội dung, đủ 4 lựa chọn và đáp án đúng A/B/C/D." });
    }
    const result = await pool.query(
      `INSERT INTO m16_questions(content,options,correct_answer,topic,difficulty,explanation)
       VALUES($1,$2,$3,$4,$5,$6) RETURNING id,content,options,topic,difficulty`,
      [content, JSON.stringify(options), correctAnswer, topic || "general", difficulty, explanation]
    );
    res.status(201).json({ question: result.rows[0] });
  } catch (e) { next(e); }
});

router.put("/admin/questions/:id", requireRole("admin"), async (req, res, next) => {
  try {
    const { content, options, correctAnswer, topic, difficulty, explanation, isActive } = req.body;
    const result = await pool.query(
      `UPDATE m16_questions SET content=COALESCE($1,content),options=COALESCE($2,options),
       correct_answer=COALESCE($3,correct_answer),topic=COALESCE($4,topic),
       difficulty=COALESCE($5,difficulty),explanation=COALESCE($6,explanation),
       is_active=COALESCE($7,is_active) WHERE id=$8
       RETURNING id,content,options,topic,difficulty,is_active`,
      [content ?? null, options ? JSON.stringify(options) : null, correctAnswer ?? null,
       topic ?? null, difficulty ?? null, explanation ?? null, isActive ?? null, req.params.id]
    );
    if (!result.rowCount) return res.status(404).json({ message: "Không tìm thấy câu hỏi." });
    res.json({ question: result.rows[0] });
  } catch (e) { next(e); }
});

router.delete("/admin/questions/:id", requireRole("admin"), async (req, res, next) => {
  try {
    const result = await pool.query("UPDATE m16_questions SET is_active=FALSE WHERE id=$1 RETURNING id", [req.params.id]);
    if (!result.rowCount) return res.status(404).json({ message: "Không tìm thấy câu hỏi." });
    res.json({ message: "Đã ẩn câu hỏi." });
  } catch (e) { next(e); }
});

// Mentor: thống kê tổng quan; có thể bổ sung tên từ bảng users của M20.
router.get("/mentor/stats", requireRole("mentor", "admin"), async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT user_id,COALESCE((SELECT SUM(xp) FROM m16_xp_events x WHERE x.user_id=p.user_id),0)::int AS total_xp,
       COUNT(*) FILTER(WHERE is_completed)::int AS completed_nodes,COUNT(*)::int AS tracked_nodes
       FROM m16_progress p GROUP BY user_id ORDER BY total_xp DESC`
    );
    res.json({ learners: result.rows });
  } catch (e) { next(e); }
});

export default router;
