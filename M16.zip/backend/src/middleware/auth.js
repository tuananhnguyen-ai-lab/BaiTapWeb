import jwt from "jsonwebtoken";

export function requireAuth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;

  // Chỉ dùng x-user-id để demo local. Production phải xác thực JWT từ M20.
  if (!token && process.env.NODE_ENV === "development" && req.headers["x-user-id"]) {
    req.user = {
      id: Number(req.headers["x-user-id"]),
      role: req.headers["x-user-role"] || "learner"
    };
    return next();
  }

  if (!token) return res.status(401).json({ message: "Vui lòng đăng nhập." });
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = {
      id: Number(decoded.id || decoded.userId || decoded.sub),
      role: decoded.role || "learner"
    };
    if (!Number.isInteger(req.user.id) || req.user.id <= 0) {
      return res.status(401).json({ message: "Token không chứa user id hợp lệ." });
    }
    next();
  } catch {
    return res.status(401).json({ message: "Token không hợp lệ hoặc đã hết hạn." });
  }
}

export function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ message: "Bạn không có quyền thực hiện chức năng này." });
    }
    next();
  };
}
