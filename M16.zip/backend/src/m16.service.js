import { pool } from "./db.js";

export function classifyScore(score) {
  if (score <= 25) return { level: "Beginner", path: "HTML cơ bản" };
  if (score <= 50) return { level: "Basic", path: "HTML và CSS" };
  if (score <= 75) return { level: "Intermediate", path: "JavaScript và DOM" };
  return { level: "Advanced", path: "JavaScript nâng cao" };
}

export async function awardXp(client, userId, eventKey, reason, xp) {
  const result = await client.query(
    `INSERT INTO m16_xp_events(user_id,event_key,reason,xp)
     VALUES($1,$2,$3,$4) ON CONFLICT(user_id,event_key) DO NOTHING RETURNING xp`,
    [userId, eventKey, reason, xp]
  );
  return result.rowCount ? xp : 0;
}

export async function updateStreak(client, userId) {
  await client.query(
    `INSERT INTO m16_streaks(user_id,current_streak,longest_streak,last_study_date)
     VALUES($1,1,1,CURRENT_DATE)
     ON CONFLICT(user_id) DO UPDATE SET
       current_streak = CASE
         WHEN m16_streaks.last_study_date = CURRENT_DATE THEN m16_streaks.current_streak
         WHEN m16_streaks.last_study_date = CURRENT_DATE - INTERVAL '1 day' THEN m16_streaks.current_streak + 1
         ELSE 1 END,
       longest_streak = GREATEST(
         m16_streaks.longest_streak,
         CASE
           WHEN m16_streaks.last_study_date = CURRENT_DATE THEN m16_streaks.current_streak
           WHEN m16_streaks.last_study_date = CURRENT_DATE - INTERVAL '1 day' THEN m16_streaks.current_streak + 1
           ELSE 1 END
       ),
       last_study_date = CURRENT_DATE`
    , [userId]
  );
}

export async function checkBadges(client, userId) {
  const totals = await client.query(
    `SELECT COALESCE((SELECT SUM(xp) FROM m16_xp_events WHERE user_id=$1),0)::int AS xp,
            COALESCE((SELECT current_streak FROM m16_streaks WHERE user_id=$1),0)::int AS streak`,
    [userId]
  );
  const { xp, streak } = totals.rows[0];
  await client.query(
    `INSERT INTO m16_user_badges(user_id,badge_id)
     SELECT $1,b.id FROM m16_badges b
     WHERE (b.required_xp = 0 OR $2 >= b.required_xp)
       AND (b.required_streak = 0 OR $3 >= b.required_streak)
     ON CONFLICT DO NOTHING`,
    [userId, xp, streak]
  );
}

export async function getDashboard(userId) {
  const [xp, streak, progress, badges, latestTest] = await Promise.all([
    pool.query(`SELECT COALESCE(SUM(xp),0)::int AS total_xp FROM m16_xp_events WHERE user_id=$1`, [userId]),
    pool.query(`SELECT current_streak,longest_streak,last_study_date FROM m16_streaks WHERE user_id=$1`, [userId]),
    pool.query(`SELECT COUNT(*) FILTER(WHERE is_completed)::int AS completed,
                       COUNT(*)::int AS total FROM m16_progress WHERE user_id=$1`, [userId]),
    pool.query(`SELECT b.code,b.name,b.description,b.icon,ub.earned_at
                FROM m16_user_badges ub JOIN m16_badges b ON b.id=ub.badge_id
                WHERE ub.user_id=$1 ORDER BY ub.earned_at DESC`, [userId]),
    pool.query(`SELECT score,level,recommended_path,completed_at FROM m16_test_results
                WHERE user_id=$1 ORDER BY completed_at DESC LIMIT 1`, [userId])
  ]);
  return {
    totalXp: xp.rows[0].total_xp,
    streak: streak.rows[0] || { current_streak: 0, longest_streak: 0, last_study_date: null },
    progress: progress.rows[0],
    badges: badges.rows,
    latestTest: latestTest.rows[0] || null
  };
}
