"use client";
import {useEffect,useState} from "react";
import Shell from "../../../components/Shell";
import {api} from "../../../lib/api";
export default function Achievements(){
 const [data,setData]=useState(null),[error,setError]=useState("");
 useEffect(()=>{api("/badges").then(setData).catch(e=>setError(e.message));},[]);
 return <Shell title="XP và huy hiệu">
  {error&&<p className="text-red-600">{error}</p>}
  {!data?<p>Đang tải...</p>:<div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
   {data.badges.map(b=><div key={b.code} className={`rounded-2xl border bg-white p-5 ${b.earned?"border-amber-300":"opacity-70"}`}>
    <div className="text-4xl">{b.icon}</div><h2 className="mt-3 font-bold">{b.name}</h2><p className="mt-1 text-sm text-slate-600">{b.description}</p>
    <p className="mt-3 text-sm">{b.required_xp>0?`Điều kiện: ${b.required_xp} XP`:`Điều kiện: ${b.required_streak} ngày Streak`}</p>
    <span className={`mt-3 inline-block rounded-full px-3 py-1 text-xs ${b.earned?"bg-green-100 text-green-700":"bg-slate-100 text-slate-600"}`}>{b.earned?"Đã đạt":"Chưa đạt"}</span>
   </div>)}
  </div>}
 </Shell>;
}
