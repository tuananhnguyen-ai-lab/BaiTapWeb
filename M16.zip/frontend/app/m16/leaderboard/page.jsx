"use client";
import {useEffect,useState} from "react";
import Shell from "../../../components/Shell";
import {api} from "../../../lib/api";
export default function Leaderboard(){
 const [data,setData]=useState(null),[error,setError]=useState("");
 useEffect(()=>{api("/leaderboard").then(setData).catch(e=>setError(e.message));},[]);
 return <Shell title="Bảng xếp hạng XP">
  {error&&<p className="text-red-600">{error}</p>}
  {!data?<p>Đang tải...</p>:<div className="overflow-hidden rounded-2xl border bg-white">
   <table className="w-full text-left"><thead className="bg-slate-50"><tr><th className="p-4">Hạng</th><th className="p-4">Mã người học</th><th className="p-4 text-right">Tổng XP</th></tr></thead>
   <tbody>{data.leaderboard.map(row=><tr key={row.user_id} className="border-t"><td className="p-4 font-bold">{row.rank}</td><td className="p-4">Người học #{row.user_id}</td><td className="p-4 text-right font-semibold text-indigo-700">{row.total_xp}</td></tr>)}</tbody></table>
   {!data.leaderboard.length&&<p className="p-5 text-slate-500">Chưa có dữ liệu xếp hạng.</p>}
  </div>}
 </Shell>;
}
