"use client";
import { useEffect, useState } from "react";
import Shell from "../../../components/Shell";
import { api } from "../../../lib/api";

export default function TestPage() {
  const [test,setTest] = useState(null), [answers,setAnswers] = useState({});
  const [result,setResult] = useState(null), [error,setError] = useState(""), [loading,setLoading] = useState(false);
  useEffect(()=>{ api("/test").then(setTest).catch(e=>setError(e.message)); },[]);
  async function submit(e) {
    e.preventDefault(); setLoading(true); setError("");
    try { setResult(await api("/test/submit",{method:"POST",body:JSON.stringify({testId:test.test.id,answers})})); }
    catch(e){setError(e.message);} finally{setLoading(false);}
  }
  return <Shell title="Kiểm tra trình độ đầu vào">
    {error && <p className="mb-4 rounded bg-red-50 p-3 text-red-700">{error}</p>}
    {result ? <div className="rounded-2xl border bg-white p-7">
      <p className="text-sm text-slate-500">Kết quả của bạn</p><p className="mt-2 text-4xl font-bold text-indigo-700">{result.result.score}/100</p>
      <p className="mt-3 text-xl font-semibold">{result.result.level}</p><p className="mt-1">Lộ trình đề xuất: {result.result.recommended_path}</p>
      <p className="mt-2 text-green-700">Bạn nhận được {result.gainedXp} XP.</p>
      <button className="mt-5 rounded-lg bg-indigo-600 px-4 py-2 text-white" onClick={()=>location.href="/m16"}>Về Dashboard</button>
    </div> : !test ? <p>Đang tải câu hỏi...</p> : <form onSubmit={submit} className="space-y-5">
      <div className="rounded-xl bg-indigo-50 p-4"><h2 className="font-semibold">{test.test.title}</h2><p className="text-sm text-slate-600">{test.test.description}</p><p className="mt-1 text-sm">{test.questions.length} câu hỏi</p></div>
      {test.questions.map((q,i)=><section key={q.id} className="rounded-2xl border bg-white p-5">
        <p className="mb-3 font-semibold">{i+1}. {q.content}</p>
        <div className="grid gap-2 sm:grid-cols-2">{Object.entries(q.options).map(([key,value])=><label key={key} className={`cursor-pointer rounded-lg border p-3 ${answers[q.id]===key?"border-indigo-600 bg-indigo-50":""}`}>
          <input className="mr-2" type="radio" name={`q-${q.id}`} value={key} checked={answers[q.id]===key} onChange={()=>setAnswers({...answers,[q.id]:key})}/><b>{key}.</b> {value}
        </label>)}</div>
      </section>)}
      <button disabled={loading || !test.questions.length} className="rounded-lg bg-indigo-600 px-6 py-3 font-semibold text-white disabled:opacity-50">{loading?"Đang chấm bài...":"Nộp bài kiểm tra"}</button>
    </form>}
  </Shell>;
}
