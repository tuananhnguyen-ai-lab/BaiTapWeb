"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import Shell from "../../components/Shell";
import { api } from "../../lib/api";

function Card({ title, value, note }) {
  return <div className="rounded-2xl border bg-white p-5 shadow-sm"><p className="text-sm text-slate-500">{title}</p><p className="mt-2 text-3xl font-bold">{value}</p>{note && <p className="mt-1 text-xs text-slate-500">{note}</p>}</div>;
}
export default function Dashboard() {
  const [data,setData] = useState(null), [error,setError] = useState("");
  useEffect(() => { api("/dashboard").then(setData).catch(e=>setError(e.message)); }, []);
  return <Shell title="Tổng quan học tập">
    {error && <p className="mb-4 rounded bg-red-50 p-3 text-red-700">{error}</p>}
    {!data ? <p>Đang tải dữ liệu...</p> : <>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card title="Tổng XP" value={data.totalXp}/>
        <Card title="Streak hiện tại" value={`${data.streak.current_streak} ngày`}/>
        <Card title="Streak dài nhất" value={`${data.streak.longest_streak} ngày`}/>
        <Card title="Node hoàn thành" value={`${data.progress.completed}/${data.progress.total}`}/>
      </div>
      <div className="mt-6 grid gap-5 lg:grid-cols-2">
        <section className="rounded-2xl border bg-white p-5">
          <h2 className="mb-3 font-semibold">Trình độ hiện tại</h2>
          {data.latestTest ? <><p className="text-xl font-bold text-indigo-700">{data.latestTest.level}</p><p className="mt-1 text-slate-600">Điểm: {data.latestTest.score}/100 · Lộ trình: {data.latestTest.recommended_path}</p></> : <p className="text-slate-600">Bạn chưa làm bài test đầu vào.</p>}
          <Link className="mt-4 inline-block rounded-lg bg-indigo-600 px-4 py-2 text-white" href="/m16/test">Làm bài kiểm tra</Link>
        </section>
        <section className="rounded-2xl border bg-white p-5">
          <h2 className="mb-3 font-semibold">Huy hiệu đã đạt</h2>
          {data.badges.length ? <div className="flex flex-wrap gap-3">{data.badges.map(b=><div key={b.code} className="rounded-xl bg-amber-50 p-3 text-center"><div className="text-2xl">{b.icon}</div><div className="text-sm font-medium">{b.name}</div></div>)}</div> : <p className="text-slate-500">Chưa có huy hiệu. Hãy bắt đầu học nhé!</p>}
        </section>
      </div>
      <section className="mt-5 rounded-2xl border bg-white p-5">
        <h2 className="font-semibold">Bắt đầu hành trình</h2>
        <p className="my-2 text-slate-600">Hoàn thành bài học và node để tích lũy XP, duy trì Streak và mở khóa huy hiệu.</p>
        <div className="flex flex-wrap gap-3"><Link className="rounded-lg border px-4 py-2" href="/m16/progress">Xem tiến độ</Link><Link className="rounded-lg border px-4 py-2" href="/m16/achievements">Xem thành tích</Link><Link className="rounded-lg border px-4 py-2" href="/m16/leaderboard">Bảng xếp hạng</Link></div>
      </section>
    </>}
  </Shell>;
}
