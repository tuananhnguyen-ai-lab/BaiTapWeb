"use client";
import { useEffect,useState } from "react";
import Shell from "../../../components/Shell";
import { api } from "../../../lib/api";
export default function ProgressPage(){
  const [data,setData]=useState(null),[error,setError]=useState("");
  useEffect(()=>{api("/progress").then(setData).catch(e=>setError(e.message));},[]);
  return <Shell title="Tiến độ học tập">
    {error&&<p className="text-red-600">{error}</p>}
    {!data?<p>Đang tải...</p>:<div className="rounded-2xl border bg-white p-6">
      <div className="flex justify-between"><b>Tiến độ hoàn thành</b><b>{data.percent}%</b></div>
      <div className="mt-3 h-3 overflow-hidden rounded-full bg-slate-100"><div className="h-full rounded-full bg-indigo-600" style={{width:`${data.percent}%`}}/></div>
      <p className="mt-2 text-sm text-slate-500">{data.completed} node hoàn thành trên {data.total} node được ghi nhận.</p>
      <div className="mt-6 space-y-2">{data.items.map(item=><div key={item.node_id} className="flex items-center justify-between rounded-lg border p-3"><span>{item.node_title||`Node #${item.node_id}`}</span><span className={item.is_completed?"text-green-700":"text-slate-400"}>{item.is_completed?"Hoàn thành":"Chưa hoàn thành"}</span></div>)}</div>
      {!data.items.length&&<p className="mt-4 text-slate-500">Chưa có dữ liệu. Tiến độ sẽ được cập nhật khi M10 gửi sự kiện hoàn thành node.</p>}
    </div>}
  </Shell>;
}
