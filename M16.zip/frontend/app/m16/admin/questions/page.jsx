"use client";
import {useEffect,useState} from "react";
import Shell from "../../../../components/Shell";
import {api} from "../../../../lib/api";
const empty={content:"",A:"",B:"",C:"",D:"",correctAnswer:"A",topic:"HTML",difficulty:"basic",explanation:""};
export default function AdminQuestions(){
 const [form,setForm]=useState(empty),[items,setItems]=useState([]),[error,setError]=useState(""),[message,setMessage]=useState("");
 async function load(){try{const d=await api("/admin/questions");setItems(d.questions);}catch(e){setError(e.message);}}
 useEffect(()=>{load();},[]);
 async function submit(e){e.preventDefault();setError("");setMessage("");try{
  await api("/admin/questions",{method:"POST",body:JSON.stringify({content:form.content,options:{A:form.A,B:form.B,C:form.C,D:form.D},correctAnswer:form.correctAnswer,topic:form.topic,difficulty:form.difficulty,explanation:form.explanation})});
  setForm(empty);setMessage("Đã thêm câu hỏi.");load();
 }catch(e){setError(e.message);}}
 async function hide(id){try{await api(`/admin/questions/${id}`,{method:"DELETE"});load();}catch(e){setError(e.message);}}
 return <Shell title="Admin – Ngân hàng câu hỏi">
  <p className="mb-4 text-sm text-slate-600">Trang này yêu cầu tài khoản có role admin. Khi demo local, đặt demoRole=admin trong localStorage.</p>
  {error&&<p className="mb-3 rounded bg-red-50 p-3 text-red-700">{error}</p>}{message&&<p className="mb-3 rounded bg-green-50 p-3 text-green-700">{message}</p>}
  <form onSubmit={submit} className="mb-7 grid gap-3 rounded-2xl border bg-white p-5">
   <h2 className="font-bold">Thêm câu hỏi</h2>
   <textarea required className="rounded-lg border p-3" placeholder="Nội dung câu hỏi" value={form.content} onChange={e=>setForm({...form,content:e.target.value})}/>
   {["A","B","C","D"].map(k=><input key={k} required className="rounded-lg border p-3" placeholder={`Đáp án ${k}`} value={form[k]} onChange={e=>setForm({...form,[k]:e.target.value})}/>)}
   <div className="flex flex-wrap gap-3"><label>Đáp án đúng <select className="ml-2 rounded border p-2" value={form.correctAnswer} onChange={e=>setForm({...form,correctAnswer:e.target.value})}>{["A","B","C","D"].map(x=><option key={x}>{x}</option>)}</select></label>
   <input className="rounded border p-2" value={form.topic} onChange={e=>setForm({...form,topic:e.target.value})} placeholder="Chủ đề"/></div>
   <textarea className="rounded-lg border p-3" placeholder="Giải thích đáp án" value={form.explanation} onChange={e=>setForm({...form,explanation:e.target.value})}/>
   <button className="w-fit rounded-lg bg-indigo-600 px-5 py-2 text-white">Lưu câu hỏi</button>
  </form>
  <div className="space-y-3">{items.map(q=><div key={q.id} className="flex items-start justify-between gap-4 rounded-xl border bg-white p-4"><div><b>#{q.id} · {q.topic}</b><p className="mt-1">{q.content}</p><p className="mt-1 text-xs text-slate-500">{q.is_active?"Đang hoạt động":"Đã ẩn"}</p></div>{q.is_active&&<button onClick={()=>hide(q.id)} className="rounded border px-3 py-1 text-sm text-red-600">Ẩn</button>}</div>)}</div>
 </Shell>;
}
