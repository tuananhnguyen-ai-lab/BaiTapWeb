import "./globals.css";
export const metadata = { title: "M16 - Đào tạo năng lực số", description: "Theo dõi hành trình học lập trình web" };
export default function RootLayout({ children }) {
  return <html lang="vi"><body>{children}</body></html>;
}
