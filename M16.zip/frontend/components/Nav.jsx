"use client";
import Link from "next/link";
const links = [
  ["/m16","Tổng quan"],["/m16/test","Test đầu vào"],["/m16/progress","Tiến độ"],
  ["/m16/achievements","XP & Huy hiệu"],["/m16/leaderboard","Xếp hạng"],["/m16/admin/questions","Ngân hàng câu hỏi"]
];
export default function Nav() {
  return <nav className="flex flex-wrap gap-2 border-b bg-white px-6 py-4">
    <span className="mr-4 font-bold text-indigo-700">LEARNWEB / M16</span>
    {links.map(([href,label]) => <Link key={href} href={href} className="rounded-lg px-3 py-2 text-sm hover:bg-indigo-50">{label}</Link>)}
  </nav>;
}
