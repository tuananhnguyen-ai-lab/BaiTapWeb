import Nav from "./Nav";
export default function Shell({ title, children }) {
  return <><Nav/><main className="mx-auto max-w-6xl px-5 py-8">
    <h1 className="mb-6 text-2xl font-bold">{title}</h1>{children}
  </main></>;
}
